## 使用环境
### 系统: Archlinux/Ubuntu 14.04
### 终端: xterm + tmux
### 强烈推荐的系统配置

将 `CapsLock` 键映射为 `左 Ctrl` 功能, 注意，不是交换这两个键，这样就不会因为旧习惯按了 Ctrl 导致切换大小写

使用 [xcape](https://github.com/alols/xcape) 设置 `CapsLock` 键按住为 Ctrl 功能, 按一次为 Esc 功能.

以下的配置和说明只是在上述系统中通过终端使用 vim 的配置，并不包含 `gvim` 等的配置

## 使用配置

### 依赖工具
`git`

``` bash
rm -f ~/.vimrc
rm -rf ~/.vim
git clone git@git.oschina.net:imtxc/vimrc.git ~/.vim
git clone http://github.com/gmarik/vundle.git ~/.vim/bundle/vundle
cp ~/.vim/.vimrc ~/.vimrc
vim -c "BundleInstall" -c "q" -c "q"
```

更新配置:
``` bash
cd ~/.vim
git pull
vim -c "BundleClean" -c "q" -c "q"
vim -c "BundleInstall" -c "q" -c "q"
cd -
```

### 字体
安装 [powerline-fonts](https://github.com/powerline/fonts)
如果不需要在 `vim-airline` 中使用 `powerline` 字体可以不安装

### 代码浏览、跳转
+ 用 [GNU global](http://www.gnu.org/software/global/) 中的 `gtags` 做代码导航, 用与在 vim/emacs 中进行代码跳转

+ 使用 `vim-easymotion` 插件在当前打开的文件中进行快速跳转的神级插件

+ 使用 `ctrlp/LeaderF` 插件在项目文件中进行跳转的神级插件，和 `vim-easymotion` 配合跳来跳去简直无敌

+ ~~使用 `bufexplorer` 插件在打开的 buf 中进行快速跳转~~ 这个插件和 LeaderF 功能相同，因此删除

+ 使用 `num gt` 命令在 tab 之间进行跳转, 使用 `tabline` 插件可以显示 tab 的编号

+ 使用 `The-NERD-tree` 插件在项目目录树中进行跳转

## 配置

## 插件介绍
插件的具体详细使用可以使用 :help 或者查看插件页面的 readme 文件.
### [vim-airline](https://github.com/bling/vim-airline)
类似与 `vim-powerline` 插件，可以增强 vim 状态栏的功能, 具体功能参考项目页面
####  相关配置
如果使用 powerline 字体，需要在 `.vimrc` 中添加如下内容:
```
let g:airline_powerline_fonts=1
let g:airline_theme='powerlineish'
```
如果不需要使用 powerline 字体，vim-airline 插件不需要其它配置

### [vim-easymotion](https://github.com/Lokaltog/vim-easymotion)
在代码中做快速跳转，常用快捷键 `<Leader><Leader>w` `<Leader><Leader>e` `<Leader><Leader>b` `<Leader><Leader>s`
快速跳到文件指定位置的神器级别插件

### [Align](http://www.vim.org/scripts/script.php?script_id=294)
在 vim 中使文本按照指定方式对齐的插件，使用举例:
例如有如下代码
``` C
int a = 1;
double test_b = 2;
char *test_char_ptr = NULL;
```
如果需要使上面三行代码中的 `=` 上下对齐，可以使用如下命令
```
:AlignCtrl =lp1P1I
:'<,'>Align =
```
结果如下
``` C
int a               = 1;
double test_b       = 2;
char *test_char_ptr = NULL;
```

### [ctrlp](https://github.com/kien/ctrlp.vim)
模仿 sublime text 编辑器中的 `Ctrl + P` 命令, 在工程项目中快速打开文件极其方便，神器级别的插件

快捷键，如同名称 `Ctrl + p`

在打开的浏览窗口中，使用 `Ctrl-b` 和 `Ctrl-f` 切换 buf，file, MRU 模式

### [LeaderF](https://github.com/Yggdroot/LeaderF)
类似 ctrlp 的插件，速度甚至比 ctrlp 还要快，可以二选一使用，快捷键, 如同名称 `<Leader>f`

在当前打开的 buffer 中跳转，使用 `<Leader>b`

### [echofunc.vim](http://www.vim.org/scripts/script.php?script_id=1735)
配合 ctags 在输入函数名称时提示函数原型的插件，由于当前使用 gtags 代替了 ctags + cscope 的代码索引，因此该插件暂时无效
### [fcitx.vim](https://github.com/lilydjwg/dotvim/blob/master/plugin/fcitx.vim)
插件功能: 在 vim 的 insert 模式输入中文，使用 `Esc` 回到 Normal 模式之后，不需要切换回英文输入就可以使用 vim 命令
### [grep.vim](http://www.vim.org/scripts/script.php?script_id=311)
在 vim 中使用 grep，常用快捷键 `F3/<Leader>0`
### [Indent-Guides](https://github.com/nathanaelkane/vim-indent-guides)
在 vim 中使用不同的颜色区分缩进级别，默认为关，开关快捷键 `<Leader>ig`
### [matchit](http://www.vim.org/scripts/script.php?script_id=39)
使用 `%` 在配对的括号(开始/结束标记)之间跳转
### [ultisnips](https://github.com/SirVer/ultisnips)
代码片段补全插件

快捷键 `<TAB>`

使用举例, 在 C 代码文件中输入 `for <TAB>` 会自动进行补全，同时将输入光标定位到下一个输入位置.

### [SuperTab--Van-Dewoestine](https://github.com/vim-scripts/SuperTab--Van-Dewoestine)
使用 `TAB` 进行补全

### [neocomplete](https://github.com/Shougo/neocomplete.vim)
自动补全插件， 需要 lua 支持.

### [Tagbar](https://github.com/majutsushi/tagbar)
同样依赖 ctags 的插件
### [The-NERD-Commenter](http://www.vim.org/scripts/script.php?script_id=1218)
快速注释/反注释代码

快捷键

`,cc` 注释选中代码段或者当前行

`,cu` 取消注释

`,ca` 切换注释风格，如 C 语言中的 // 和 /**/ 风格的注释切换

### [The-NERD-tree](http://www.vim.org/scripts/script.php?script_id=1658)
显示项目目录树

### [tabline](https://github.com/mkitt/tabline.vim)
固定 tab 的宽度，在文件名称前显示 tab 编号

### [surround.vim](https://github.com/tpope/vim-surround)
处理成对的包围符号, 如:

要修改 "hello world." 为 <hello world.>, 可以按 `cs">`

## 快捷键
各插件用到的快捷键在每个插件的介绍中说明，以下其它一些常用的快捷键

由于我使用的键盘没有 F1-F12 键，因此部分常用功能绑定了两个快捷键，可以使用 F1-F12 的方式，也可以使用 Leader + key 的方式

### Leader 键: `,`
如，配置中的 `nnoremap <Leader>0 :Rgrep<CR>` 就是先按 `,`, 再按 `0`

### 功能开关
打开/关闭行号: `F10/<Leader>2`

打开/关闭全部的折叠 `<Leader>3`

tagbar 开关: `F2/<Leader>1`

paste 模式开关: `F4/<Leader>4`

打开 quickfix window: `F7/<Leader>7`

关闭 quickfix window: `F8/<Leader>8`

NERDTree 开关: `F9/<Leader>9`

关闭搜索模式中的高亮: `<Leader>h`

### 代码跳转
#### 使用 global 做代码跳转
`<C-\>s` 查找符号定义位置(变量函数定义)

`<C-\>c` 查找函数在什么地方被调用

#### Rgrep: `F3/<Leader>0`

#### 内置的 tags 跳转
`C-]` 跳到函数定义

`C-o` 返回到跳转之前位置

### 标签操作
`tp` 前一个标签

`tn` 下一个标签

`to` 新建标签

`tc` 关闭标签

`Ngt` 跳到编号为 `N` 的标签

### window 操作
`C-w h/j/k/l`/`C-h/j/k/l` 窗口选择

### 和 X 共享剪切板 (需要依赖工具 `xsel`)
需要安装 gvim
在选中模式下，使用 `Ctrl-c` 复制到剪切板

在 insert 模式下，使用 `Ctrl-p` 粘帖

## TODO
+ vim-multiple-cursors 多处编辑
+ 补全插件
