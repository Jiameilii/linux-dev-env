#!/bin/bash

echo "自动安装 vim 配置以及其它第三方工具"
